library(testthat)
library(BlandAltmanEdinburgh)

test_check("BlandAltmanEdinburgh")
